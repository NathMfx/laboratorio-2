let canvas;
let URL =  'https://pokeapi.co/api/v2/pokemon/1/' //bulbasaur
let URL1 = 'https://pokeapi.co/api/v2/pokemon/2/' //ivi
let URL2 = 'https://pokeapi.co/api/v2/pokemon/3/' //venu
let URL3 = 'https://pokeapi.co/api/v2/pokemon/4/' //char
let URL4 =' https://pokeapi.co/api/v2/pokemon/5/' //charmeleon
let URL5 = 'https://pokeapi.co/api/v2/pokemon/6/' //charizar
let URL6 = 'https://pokeapi.co/api/v2/pokemon/7/' //squitlr
let URL7 = 'https://pokeapi.co/api/v2/pokemon/8/' //wartolte
let URL8 = 'https://pokeapi.co/api/v2/pokemon/9/' //blasto

let bulbasaur = null;
let bulbasaurImage
let charmander = null;
let charmanderImage
let squirtle = null;
let squirtleImage
let ivysaur = null;
let ivysaurImage = null;
let charmeleon = null;
let charmeleonImage
let wartortle = null;
let wartortleImage 
let venusaur = null;
let venusaurImage
let charizard = null;
let charizardImage
let blastoise = null;
let blastoiseImage
let estePokemon 

function setup() {
    frameRate(60);
    canvas = createCanvas(windowWidth, windowHeight);
    canvas.style('z-index', '-1');
    canvas.style('position', 'fixed');
    canvas.style('top', '0');
    canvas.style('right', '0');

    //pokemon 1
    console.log(fetch(URL).then(response => response.json()))
    fetch(URL)
    .then(response => response.json())
    .then(data => {bulbasaur=data;
    bulbasaurImage = loadImage(bulbasaur.sprites.front_default)
    console.log(bulbasaur)})

   //pokemon 2
    console.log(fetch(URL1).then(response => response.json()))
    fetch(URL1)
    .then(response => response.json())
    .then(data => {ivysaur=data;
    ivysaurImage = loadImage(ivysaur.sprites.front_default)
    console.log(ivysaur)})

    //pokemon 3
    console.log(fetch(URL2).then(response => response.json()))
    fetch(URL2)
    .then(response => response.json())
    .then(data => {venusaur=data;
    venusaurImage = loadImage(venusaur.sprites.front_default)
    console.log(venusaur)})

    //pokemon 4
    console.log(fetch(URL3).then(response => response.json()))
    fetch(URL3)
    .then(response => response.json())
    .then(data => {charmander=data;
    charmanderImage = loadImage(charmander.sprites.front_default)
    console.log(charmander)})

    //pokemon 5
    console.log(fetch(URL4).then(response => response.json()))
    fetch(URL4)
    .then(response => response.json())
    .then(data => {charmeleon=data;
    charmeleonImage = loadImage(charmeleon.sprites.front_default)
    console.log(charmeleon)})

    //pokemon 6
    console.log(fetch(URL5).then(response => response.json()))
    fetch(URL5)
    .then(response => response.json())
    .then(data => {charizard=data;
    charizardImage = loadImage(charizard.sprites.front_default)
    console.log(charizard)})

    //pokemon 7
    console.log(fetch(URL6).then(response => response.json()))
    fetch(URL6)
    .then(response => response.json())
    .then(data => {squirtle=data;
    squirtleImage = loadImage(squirtle.sprites.front_default)
    console.log(squirtle)})

    //pokemon 8
    console.log(fetch(URL7).then(response => response.json()))
    fetch(URL7)
    .then(response => response.json())
    .then(data => {wartortle=data;
    wartortleImage = loadImage(wartortle.sprites.front_default)
    console.log(wartortle)})

    //pokemon 9
    console.log(fetch(URL8).then(response => response.json()))
    fetch(URL8)
    .then(response => response.json())
    .then(data => {blastoise=data;
    blastoiseImage = loadImage(blastoise.sprites.front_default)
    console.log(blastoise)})


}






function draw() {
    //background(0, 50);
    background(0);
    newCursor();
    
    //pokemon 1
    if(bulbasaur != null){
        textSize(28);
    text(bulbasaur.name, 100,40,100,100)
    image(bulbasaurImage, 40,15,250,250)
    }
    //pokemon 2
    if(ivysaur != null){
        textSize(28);
    text(ivysaur.name, 110,210,100,100)
    image(ivysaurImage, 50,200,200,200)
    }
    //pokemon 3
    if(venusaur != null){
        textSize(28);
    text(venusaur.name, 80,380,200,200)
    image(venusaurImage, 65,390,150,150)
    }
    //pokemon 4
    if(charmander != null){
        textSize(30);
    text(charmander.name, 60,550,200,200)
    image(charmanderImage, 20,520,250,250)
    }
    //pokemon 5
    if(charmeleon != null){
        textSize(30);
    text(charmeleon.name, 60,750,200,200)
    image(charmeleonImage, 50,760,200,200)
    }
    //pokemon 6
    if(charizard != null){
        textSize(30);
    text(charizard.name, 420,40,200,200)
    image(charizardImage, 400,65,170,170)
    }
    //pokemon 7
    if(squirtle != null){
        textSize(30);
    text(squirtle.name, 440,260,200,200)
    image(squirtleImage, 370,240,250,250)
    }
    //pokemon 8
    if(wartortle != null){
        textSize(30);
    text(wartortle.name, 435,450,200,200)
    image(wartortleImage, 395,450,200,200)
    }
    //pokemon 9
    if(blastoise != null){
        textSize(30);
    text(blastoise.name, 435,660,200,200)
    image(blastoiseImage, 400,670,200,200)
    }

    if(estePokemon != null){
        text(estePokemon.name, 400, 100)
        text(estePokemon.abilities, 400, 150)
    }

}

function mouseClicked(){}
    if (pmouseX > 100 && pmouseX < 140 &&
       pmouseY > 100 && pmouseY < 150)
    
function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}

function newCursor() {
    noStroke();
    fill(255);
    ellipse(pmouseX, pmouseY, 10, 10);
}

